/** Minimal React integration. Copy alongside the two .ts helpers. */
import { useMemo, useRef, useState } from "react";
import {
  CommandIntent, CommandRecord, DeviceApi, TEST_DEVICE,
  TERMINAL, createIntent, deviceView,
} from "./device-client";
import { useDevice } from "./use-device";

// Current public test environment only. For secure mode, use a memoized Firebase
// token supplier in DeviceApi and useDevice, and set publicTestMode=false.
export default function DevicePanel() {
  const api = useMemo(() => new DeviceApi(), []);
  const device = useDevice({ api, ...TEST_DEVICE, publicTestMode: true });
  const intent = useRef<CommandIntent | null>(null);
  const busy = useRef(false);
  const [submitting, setSubmitting] = useState(false);
  const [accepted, setAccepted] = useState<CommandRecord | null>(null);
  const [submissionError, setSubmissionError] = useState<string>();
  const command = device.commands.find(c => c.commandId === accepted?.commandId) ?? accepted;
  const pending = command !== null && !TERMINAL.has(command.status);
  const reviewRequired = command?.status === "needs_reconciliation";

  async function queryBattery() {
    if (busy.current || pending || reviewRequired) return;
    busy.current = true;
    setSubmitting(true);
    setSubmissionError(undefined);
    // Retain intent on errors. A retry uses the exact same key/body.
    intent.current ??= createIntent(TEST_DEVICE.deviceId, {
      type: "battery", sms: "battery", params: {}, transport: "tcp",
    });
    try {
      setAccepted(await device.submit(intent.current));
      intent.current = null;
    } catch (error) {
      setSubmissionError(String(error));
    } finally {
      busy.current = false;
      setSubmitting(false);
    }
  }

  const view = device.snapshot ? deviceView(device.snapshot) : null;
  return (
    <section aria-label="Owned test device">
      <h1>Device</h1>
      <p>Profile: {TEST_DEVICE.profileId}</p>
      <p>Realtime: {device.socket} · Device last seen: {device.snapshot?.lastSeen ?? "Unknown"}</p>
      {(view?.simulatedLocation || view?.emulatorActive) && <p><strong>Simulated telemetry</strong></p>}
      <p>Battery: {view?.battery == null ? "Unknown" : `${view.battery}%`}</p>
      <p>Location: {view?.coordinates
        ? `${view.coordinates.latitude}, ${view.coordinates.longitude}` : "No location received"}</p>
      <p>Measurement time: {view?.locationTime ?? "Unknown"}</p>
      {device.error && <p role="alert">Refresh failed; displayed data may be stale. {device.error}</p>}
      {submissionError && <p role="alert">Submission was not confirmed. Check the error; an HTTP retry keeps the same intent. {submissionError}</p>}
      <button type="button" disabled={submitting || pending || reviewRequired} onClick={() => void queryBattery()}>
        {submitting ? "Submitting…" : pending ? "Waiting for device…" : intent.current ? "Retry same battery request" : "Query battery over TCP"}
      </button>
      <button type="button" onClick={device.refresh}>Refresh saved state</button>
      {command && <p role="status">Command {command.commandId}: {command.status}</p>}
      {reviewRequired && <p>Backend review is required before repeating this action.</p>}
      <h2>Recent commands</h2>
      <ul>{device.commands.slice(0, 10).map((c, index) => (
        <li key={c.commandId ?? `imported-${index}`}>{c.type ?? "Imported command"}: {c.status}</li>
      ))}</ul>
      <p>{device.alerts.length} recent alerts · {device.jobs.length} configuration jobs</p>
    </section>
  );
}
