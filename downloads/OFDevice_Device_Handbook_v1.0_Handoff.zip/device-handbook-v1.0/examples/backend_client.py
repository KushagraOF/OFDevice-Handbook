"""OFDevice v1.0 BE example. Standard library only; importing makes no requests.

Pass an operator token from server-side environment for privileged secure-mode
actions. Never forward that token to the browser. This example submits no call,
SMS or carrier action automatically. Persist an Intent before a critical write.
"""
from dataclasses import dataclass
import json
import os
import time
import uuid
from urllib.error import HTTPError
from urllib.parse import quote
from urllib.request import Request, urlopen

TERMINAL = {"succeeded", "failed", "expired", "needs_reconciliation", "cancelled"}
TEST_DEVICE_ID = "cfb2f962-9551-5684-898b-2809dd4cee92"


@dataclass(frozen=True)
class Intent:
    device_id: str
    key: str
    body_json: str


def new_intent(device_id: str, body: dict) -> Intent:
    """One new user intent. Reuse this exact object for an HTTP retry."""
    return Intent(device_id, str(uuid.uuid4()), json.dumps(body, sort_keys=True))


class DeviceClient:
    def __init__(self, base_url="https://devices.oceanfriendswebsocket.com", token=None):
        self.base_url = base_url.rstrip("/")
        self.token = token

    def request(self, method: str, path: str, body_json=None, key=None):
        headers = {"Accept": "application/json"}
        if self.token:
            headers["Authorization"] = "Bearer " + self.token
        if key:
            headers["Idempotency-Key"] = key
        body = body_json.encode() if body_json is not None else None
        if body is not None:
            headers["Content-Type"] = "application/json"
        request = Request(self.base_url + path, data=body, headers=headers, method=method)
        try:
            with urlopen(request, timeout=15) as response:
                return json.load(response)
        except HTTPError as error:
            detail = error.read().decode(errors="replace")
            raise RuntimeError(f"OFDevice HTTP {error.code}: {detail}") from error

    def snapshot(self, device_id: str):
        return self.request("GET", "/v1/devices/" + quote(device_id, safe=""))

    def commands(self, device_id: str):
        return self.request("GET", "/v1/devices/" + quote(device_id, safe="") + "/commands?limit=100")["data"]

    def submit(self, intent: Intent):
        # No automatic retries. On network ambiguity the caller retains intent.
        return self.request("POST", "/v1/devices/" + quote(intent.device_id, safe="") + "/commands",
                            body_json=intent.body_json, key=intent.key)

    def wait_for_command(self, device_id: str, command_id: str, seconds=90):
        deadline = time.monotonic() + seconds
        last = None
        while time.monotonic() < deadline:
            last = next((c for c in self.commands(device_id) if c.get("commandId") == command_id), last)
            if last and last.get("status") in TERMINAL:
                return last  # needs_reconciliation is an unknown outcome, not success
            time.sleep(2)
        # A polling deadline never resubmits an action or changes backend status.
        return {"pollingTimedOut": True, "commandId": command_id, "lastObserved": last}


if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser(description="Read current test device; optional deliberate TCP battery query")
    parser.add_argument("--device-id", default=TEST_DEVICE_ID)
    parser.add_argument("--battery", action="store_true", help="Submit one real TCP battery read")
    args = parser.parse_args()
    client = DeviceClient(token=os.environ.get("OFDEVICE_OPERATOR_TOKEN"))
    print(json.dumps(client.snapshot(args.device_id), indent=2))
    if args.battery:
        intent = new_intent(args.device_id, {"type": "battery", "sms": "battery", "params": {}, "transport": "tcp"})
        # In a real backend, durably save intent/key before submitting, and recover it after a restart.
        command = client.submit(intent)
        print(json.dumps({"intentKey": intent.key, "accepted": command}, indent=2))
        print(json.dumps(client.wait_for_command(args.device_id, command["commandId"]), indent=2))
