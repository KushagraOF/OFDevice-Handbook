/** Install in your React app. Memoize `api` and `getToken` in the caller. */
import { useEffect, useRef, useState } from "react";
import {
  DeviceApi, DeviceSnapshot, CommandRecord, CommandIntent, SocketState,
  subscribeProfile, isPending,
} from "./device-client";

interface State {
  snapshot?: DeviceSnapshot;
  commands: CommandRecord[];
  alerts: Record<string, unknown>[];
  jobs: Record<string, unknown>[];
  socket: SocketState;
  error?: string;
}
export function useDevice(options: {
  api: DeviceApi; deviceId: string; profileId: string;
  centerId: string; phoneNumber: string; publicTestMode: boolean;
  getToken?: () => Promise<string>;
}) {
  const [state, setState] = useState<State>({
    commands: [], alerts: [], jobs: [], socket: "connecting",
  });
  const refreshRef = useRef<() => void>(() => {});
  const { api, deviceId, profileId, centerId, phoneNumber, publicTestMode, getToken } = options;

  useEffect(() => {
    let disposed = false;
    let running = false;
    let dirty = false;
    let pending = false;
    let rapidUntil = 0;
    let timer: ReturnType<typeof setTimeout> | undefined;
    const controller = new AbortController();
    setState({ commands: [], alerts: [], jobs: [], socket: "connecting" });
    const schedule = (delay = 150) => {
      if (disposed) return;
      clearTimeout(timer);
      timer = setTimeout(refresh, delay);
    };
    async function refresh() {
      if (disposed) return;
      if (running) { dirty = true; return; }
      running = true;
      dirty = false;
      try {
        const [snapshot, commands, alerts, jobs] = await Promise.all([
          api.snapshot(deviceId, controller.signal), api.commands(deviceId, controller.signal),
          api.alerts(deviceId, controller.signal), api.jobs(deviceId, controller.signal),
        ]);
        if (disposed) return;
        pending = commands.data.some(isPending);
        if (pending && !rapidUntil) rapidUntil = Date.now() + 90_000;
        if (!pending) rapidUntil = 0;
        setState(s => ({ ...s, snapshot, commands: commands.data, alerts: alerts.data, jobs: jobs.data, error: undefined }));
      } catch (error) {
        if (!disposed) setState(s => ({ ...s, error: String(error) }));
      } finally {
        running = false;
        if (!disposed) schedule(dirty ? 150 : pending && Date.now() < rapidUntil ? 3000 : 30_000);
      }
    }
    refreshRef.current = () => schedule();
    const stop = subscribeProfile({
      profileId, centerId, phoneNumber, publicTestMode, getToken,
      onState: socket => { if (!disposed) setState(s => ({ ...s, socket })); },
      onHint: () => schedule(),
    });
    const visible = () => { if (document.visibilityState === "visible") schedule(); };
    document.addEventListener("visibilitychange", visible);
    void refresh();
    return () => {
      disposed = true;
      refreshRef.current = () => {};
      controller.abort();
      clearTimeout(timer);
      stop();
      document.removeEventListener("visibilitychange", visible);
    };
  }, [api, deviceId, profileId, centerId, phoneNumber, publicTestMode, getToken]);

  // The caller retains the intent on failure. Do not auto-generate a replacement key.
  async function submit(intent: CommandIntent) {
    if (intent.deviceId !== deviceId) throw new Error("Intent belongs to another device");
    const result = await api.submit(intent);
    refreshRef.current();
    return result;
  }
  return { ...state, refresh: () => refreshRef.current(), submit };
}

/* Example caller:
const api = useMemo(() => new DeviceApi(), []); // public test only
const device = useDevice({ api, ...TEST_DEVICE, publicTestMode: true });
const intentRef = useRef<CommandIntent | null>(null);
async function batteryQuery() {
  intentRef.current ??= createIntent(TEST_DEVICE.deviceId, {
    type: "battery", sms: "battery", params: {}, transport: "tcp"
  });
  try { await device.submit(intentRef.current); intentRef.current = null; }
  catch (e) { // retain intentRef for a deliberate HTTP retry; show error }
}
Use a separate submitting flag to disable repeated clicks. Once accepted, track
the returned commandId in history; do not label it completed yet. For secure mode,
pass a memoized Firebase ID-token supplier to both DeviceApi and useDevice.
*/
