/** OFDevice handbook v1.0. Browser HTTP + realtime; no operator secrets here. */
export type CommandStatus =
  | "queued" | "in_flight" | "dispatching" | "awaiting_device"
  | "succeeded" | "failed" | "expired" | "needs_reconciliation" | "cancelled";

export type DeviceSlot = 1 | 2 | 3 | 4 | 5 | 6 | 7 | 8 | 9 | 10;
export type CommandType =
  | "battery" | "status" | "version" | "location" | "gps_location"
  | "check_contacts" | "check_gprs" | "continuous_locate" | "mode"
  | "internet" | "webhook" | "timezone" | `contact_${DeviceSlot}`
  | "remove_contact" | `geofence_${DeviceSlot}` | `alarm_clock_${number}`
  | "no_disturb" | "fall_alarm" | "motion_alarm" | "no_motion_alarm"
  | "led" | "vibrate" | "findme" | "find_me" | "reboot" | "turn_off"
  | "flush" | "scan_ble" | "ble" | "tts_speak" | "ringtone_volume"
  | "mic_volume" | "speaker_volume" | "voice_volume" | "language"
  | "wifi" | "beep" | "low_battery" | "answer" | "callin"
  | "power_on_alert" | "power_off_alert" | "heartbeat" | "gps_url"
  | "gprs" | "custom";

export interface CommandBody {
  type: CommandType;
  sms: string;
  params?: Record<string, unknown>;
  transport: "tcp" | "sms" | "auto";
}
export interface CommandRecord {
  commandId?: string; // schemaVersion=0 imported history may have no commandId
  schemaVersion?: number;
  status: CommandStatus | (string & {});
  type?: string;
  delivery?: "tcp" | "sms";
  transportPreference?: string;
  created_at?: string;
  updatedAt?: string;
  error?: unknown;
  [field: string]: unknown;
}
export interface DeviceSnapshot {
  deviceId: string;
  profileId: string;
  imei?: string;
  phoneNumber?: string;
  version?: number;
  enrollmentActive?: boolean;
  lastSeen?: string;
  batteryLevel?: number;
  batteryUpdatedAt?: string;
  lastLocation?: {
    latitude?: number; longitude?: number; timestamp?: string;
    receivedAt?: string; simulation?: boolean; simulationRunId?: string;
    [field: string]: unknown;
  };
  simulation?: { active?: boolean; writesPersistAfterStop?: boolean };
  [field: string]: unknown;
}

export const TEST_DEVICE = Object.freeze({
  deviceId: "cfb2f962-9551-5684-898b-2809dd4cee92",
  profileId: "39804d16-943d-4b62-9335-2fda2185ccc7",
  centerId: "999", phoneNumber: "+14695400192", imei: "866484030221567",
});

export const TERMINAL = new Set<string>([
  "succeeded", "failed", "expired", "needs_reconciliation", "cancelled",
]);
export const isPending = (c: CommandRecord): boolean =>
  c.schemaVersion === 1 && !TERMINAL.has(c.status);

/** Keep this object for a retry. A deliberate new action creates a new object. */
export interface CommandIntent {
  readonly deviceId: string;
  readonly key: string;
  readonly bodyJson: string;
}
export function createIntent(deviceId: string, body: CommandBody): CommandIntent {
  return Object.freeze({ deviceId, key: crypto.randomUUID(), bodyJson: JSON.stringify(body) });
}

export class DeviceApiError extends Error {
  constructor(public readonly status: number, public readonly detail: unknown) {
    super(`OFDevice HTTP ${status}: ${typeof detail === "string" ? detail : JSON.stringify(detail)}`);
  }
}

export class DeviceApi {
  constructor(
    public readonly baseUrl = "https://devices.oceanfriendswebsocket.com",
    private readonly getToken?: () => Promise<string>,
  ) {}

  async request<T>(path: string, init: RequestInit = {}): Promise<T> {
    const controller = new AbortController();
    const upstream = init.signal;
    const cancel = () => controller.abort();
    if (upstream?.aborted) controller.abort();
    upstream?.addEventListener("abort", cancel, { once: true });
    const timer = setTimeout(cancel, 12_000);
    try {
      const headers = new Headers(init.headers);
      if (init.body) headers.set("Content-Type", "application/json");
      if (this.getToken) headers.set("Authorization", `Bearer ${await this.getToken()}`);
      const response = await fetch(this.baseUrl.replace(/\/$/, "") + path, {
        ...init, credentials: "omit", headers, signal: controller.signal,
      });
      const text = await response.text();
      let data: unknown;
      try { data = text ? JSON.parse(text) : null; } catch { data = { detail: text }; }
      if (!response.ok) {
        const detail = typeof data === "object" && data !== null && "detail" in data
          ? (data as { detail: unknown }).detail : data;
        throw new DeviceApiError(response.status, detail);
      }
      return data as T;
    } finally {
      clearTimeout(timer);
      upstream?.removeEventListener("abort", cancel);
    }
  }

  snapshot(deviceId: string, signal?: AbortSignal): Promise<DeviceSnapshot> {
    return this.request(`/v1/devices/${encodeURIComponent(deviceId)}`, { signal });
  }
  commands(deviceId: string, signal?: AbortSignal): Promise<{ data: CommandRecord[] }> {
    return this.request(`/v1/devices/${encodeURIComponent(deviceId)}/commands?limit=100`, { signal });
  }
  alerts(deviceId: string, signal?: AbortSignal): Promise<{ data: Record<string, unknown>[] }> {
    return this.request(`/v1/devices/${encodeURIComponent(deviceId)}/alerts?limit=100`, { signal });
  }
  jobs(deviceId: string, signal?: AbortSignal): Promise<{ data: Record<string, unknown>[] }> {
    return this.request(`/v1/devices/${encodeURIComponent(deviceId)}/provisioning`, { signal });
  }
  submit(intent: CommandIntent, signal?: AbortSignal): Promise<CommandRecord> {
    return this.request(`/v1/devices/${encodeURIComponent(intent.deviceId)}/commands`, {
      method: "POST", headers: { "Idempotency-Key": intent.key },
      body: intent.bodyJson, signal,
    });
  }
}

export type SocketState = "connecting" | "connected" | "reconnecting" | "authentication_required";
export interface SubscriptionOptions {
  profileId: string; centerId: string; phoneNumber: string;
  publicTestMode: boolean;
  getToken?: () => Promise<string>;
  realtimeBase?: string;
  onState: (state: SocketState) => void;
  onHint: (message: Record<string, unknown>) => void;
}

/** Public hello is immediate. Secure hello follows first-message token auth. */
export function subscribeProfile(options: SubscriptionOptions): () => void {
  const segments = [options.profileId, options.centerId, options.phoneNumber].map(encodeURIComponent);
  const url = (options.realtimeBase ?? "wss://device-events.oceanfriendswebsocket.com").replace(/\/$/, "")
    + "/websocket/" + segments.join("/");
  let stopped = false;
  let socket: WebSocket | undefined;
  let retry: ReturnType<typeof setTimeout> | undefined;
  let ping: ReturnType<typeof setInterval> | undefined;
  let renewal: ReturnType<typeof setTimeout> | undefined;
  let attempt = 0;
  let fatal = false;
  const clearConnectionTimers = () => { clearInterval(ping); clearTimeout(renewal); };

  function connect(): void {
    if (stopped) return;
    options.onState(attempt ? "reconnecting" : "connecting");
    const current = new WebSocket(url);
    socket = current;
    let lastPong = Date.now();
    current.onopen = async () => {
      try {
        if (!options.publicTestMode) {
          if (!options.getToken) throw new Error("Firebase token supplier required");
          const token = await options.getToken();
          if (stopped || socket !== current || current.readyState !== WebSocket.OPEN) return;
          current.send(JSON.stringify({ type: "authenticate", token }));
        }
        if (stopped || current.readyState !== WebSocket.OPEN) return;
        ping = setInterval(() => {
          if (current.readyState !== WebSocket.OPEN) return;
          if (Date.now() - lastPong > 65_000) current.close(4000, "Heartbeat expired");
          else current.send(JSON.stringify({ type: "ping" }));
        }, 20_000);
        renewal = setTimeout(() => current.close(4000, "Refresh session"), 52 * 60_000);
      } catch {
        fatal = true;
        options.onState("authentication_required");
        current.close(1000);
      }
    };
    current.onmessage = ({ data }) => {
      if (stopped || socket !== current) return;
      try {
        const message: unknown = JSON.parse(String(data));
        if (!message || typeof message !== "object" || Array.isArray(message)) return;
        const event = message as Record<string, unknown>;
        if (event.type === "pong") { lastPong = Date.now(); return; }
        if (event.type === "resync_required") {
          attempt = 0;
          options.onState("connected");
        }
        options.onHint(event); // Includes envelope hints that have no eventId.
      } catch { /* Invalid non-JSON server data cannot replace the HTTP snapshot. */ }
    };
    current.onclose = ({ code }) => {
      if (socket !== current) return;
      clearConnectionTimers();
      if (stopped || fatal) return;
      if (code === 1008) { options.onState("authentication_required"); return; }
      options.onState("reconnecting");
      const ceiling = Math.min(30_000, 1000 * 2 ** Math.min(attempt++, 5));
      retry = setTimeout(connect, ceiling * (0.5 + Math.random() * 0.5));
    };
    current.onerror = () => { /* onclose controls retries; never create a second socket here. */ };
  }
  connect();
  return () => {
    stopped = true;
    clearTimeout(retry);
    clearConnectionTimers();
    socket?.close(1000, "View closed");
  };
}

/** A derived view model; no invented hardware-online boolean. */
export function deviceView(snapshot: DeviceSnapshot, now = Date.now()) {
  const l = snapshot.lastLocation;
  const lat = l?.latitude;
  const lng = l?.longitude;
  const coordinates = typeof lat === "number" && typeof lng === "number"
    && Number.isFinite(lat) && Number.isFinite(lng) && Math.abs(lat) <= 90 && Math.abs(lng) <= 180
    ? { latitude: lat, longitude: lng } : null;
  const seen = snapshot.lastSeen ? Date.parse(snapshot.lastSeen) : NaN;
  const battery = snapshot.batteryLevel;
  return {
    coordinates,
    battery: typeof battery === "number" && Number.isFinite(battery) && battery >= 0 && battery <= 100 ? battery : null,
    lastSeenAgeMs: Number.isFinite(seen) ? Math.max(0, now - seen) : null,
    locationTime: l?.timestamp ?? null,
    simulatedLocation: l?.simulation === true,
    emulatorActive: snapshot.simulation?.active === true,
  };
}
